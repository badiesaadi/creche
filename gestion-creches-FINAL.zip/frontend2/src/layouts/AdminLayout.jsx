import { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useAuth } from "../lib/auth/AuthContext.jsx";
import NotificationsBell from "../components/shared/NotificationsBell.jsx";

const navItems = [
  { to: "/admin/dashboard", labelKey: "nav.dashboard", icon: "📊" },
  { to: "/admin/creches", labelKey: "nav.creches", icon: "🏠" },
  { to: "/admin/children", labelKey: "admin.childrenNetwork", icon: "👶" },
  { to: "/admin/hr", labelKey: "nav.hr", icon: "👤" },
  { to: "/admin/finance", labelKey: "nav.finance", icon: "💰" },
  { to: "/admin/expenses", labelKey: "admin.expenses", icon: "📋" },
  { to: "/admin/reports", labelKey: "nav.reports", icon: "📄" },
];

export default function AdminLayout() {
  const { t, i18n } = useTranslation();
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  function handleLogout() {
    logout();
    navigate("/login");
  }

  const Sidebar = () => (
    <div className="flex flex-col h-full bg-gray-900 text-white w-64">
      <div className="p-5 border-b border-gray-700">
        <p className="font-bold text-lg text-teal-400">PAI — Admin</p>
      </div>
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink key={item.to} to={item.to} onClick={() => setMobileOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                isActive ? "bg-teal-600 text-white" : "text-gray-300 hover:bg-gray-800 hover:text-white"
              }`
            }>
            <span>{item.icon}</span>
            <span>{t(item.labelKey)}</span>
          </NavLink>
        ))}
      </nav>
      <div className="p-3 border-t border-gray-700 space-y-2">
        <div className="flex gap-1 px-2">
          {["ar", "fr", "en"].map((lang) => (
            <button key={lang} onClick={() => i18n.changeLanguage(lang)}
              className={`flex-1 py-1 rounded text-xs font-medium ${i18n.language === lang ? "bg-teal-600 text-white" : "text-gray-400 hover:text-white"}`}>
              {lang.toUpperCase()}
            </button>
          ))}
        </div>
        <button onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium text-gray-300 hover:bg-gray-800 hover:text-white">
          <span>🚪</span><span>{t("auth.logout")}</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Desktop sidebar */}
      <div className="hidden md:flex flex-shrink-0"><Sidebar /></div>

      {/* Mobile sidebar overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div className="flex-shrink-0"><Sidebar /></div>
          <div className="flex-1 bg-black/50" onClick={() => setMobileOpen(false)} />
        </div>
      )}

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile topbar */}
        <div className="md:hidden flex items-center justify-between bg-white border-b border-gray-200 p-3">
          <button onClick={() => setMobileOpen(true)} className="text-gray-700">☰</button>
          <span className="font-bold text-teal-700">PAI — Admin</span>
          <NotificationsBell />
        </div>
        {/* Desktop topbar */}
        <div className="hidden md:flex items-center justify-end bg-white border-b border-gray-200 px-6 py-2">
          <NotificationsBell />
        </div>

        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
