import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { apiClient } from "../../lib/api/client.js";
import { useAuth } from "../../lib/auth/AuthContext.jsx";

export default function LoginPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { login } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
  e.preventDefault();
  setError("");
  setLoading(true);

  // TODO: replace with real API call -> apiClient.post("/auth/login", { email, password })
  await new Promise((r) => setTimeout(r, 500)); // fake network delay

  const mockUsers = {
    "admin@pai.dz": { password: "admin123", user: { id: 1, nom: "Admin PAI", role: "admin" } },
    "manager@pai.dz": { password: "manager123", user: { id: 2, nom: "Sara Manager", role: "manager", crecheId: 1 } },
    "teacher@pai.dz": { password: "teacher123", user: { id: 3, nom: "Amine Teacher", role: "teacher", crecheId: 1 } },
  };

  const entry = mockUsers[email];

  if (!entry || entry.password !== password) {
    setError(t("common.error"));
    setLoading(false);
    return;
  }

  login(entry.user, "fake-access-token", "fake-refresh-token");

  if (entry.user.role === "admin") navigate("/admin/dashboard");
  else navigate("/creche/dashboard");

  setLoading(false);
}

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm bg-white p-8 rounded-xl shadow-md space-y-5"
      >
        <h1 className="text-2xl font-bold text-center text-gray-800">
          {t("auth.login")}
        </h1>

        {error && (
          <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-md p-2">
            {error}
          </p>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            {t("auth.email")}
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            {t("auth.password")}
          </label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-teal-600 text-white rounded-md py-2 font-medium hover:bg-teal-700 disabled:opacity-50"
        >
          {loading ? t("common.loading") : t("auth.submit")}
        </button>
      </form>
    </div>
  );
}